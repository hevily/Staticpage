/*===========================
 Get jQuery
 ===========================*/
addLibraryPlugin($);

var domLib = $;
